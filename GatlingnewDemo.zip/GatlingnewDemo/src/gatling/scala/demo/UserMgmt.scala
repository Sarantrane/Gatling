package demo

import io.gatling.core.Predef._
import io.gatling.core.scenario.Simulation
import io.gatling.http.Predef._

class UserMgmt extends Simulation {


  val httpconfig = http.baseUrl("https://connect.tis-dev.trane.com")
    .header("Accept", "application/json")
    .header("content-type", "application/json")


  //scenario
  val scn =scenario("get UserManagement")
    .exec(http("get UserManagement Request")
      .get("/user-management-new")
      .check(status is 200))

  setUp(scn.inject(atOnceUsers(10))).protocols(httpconfig)


}




